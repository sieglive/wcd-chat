# coding:utf-8
"""Module of models"""

from .wcd_mongo import M_CLIENT as m_client